
<?php
if($page=='home')
{
    
?>         
<?php $this->load->view('admin/home'); ?>

<?php

}
else if($page=='absen')
{
    
?>         
<?php $this->load->view('admin/absen'); ?>

<?php

}
else if($page=='report_absen')
{
    
?>         
<?php $this->load->view('admin/report_absen'); ?>

<?php

}
else if($page=='add_absen')
{
    
?>         
<?php $this->load->view('admin/add_absen'); ?>

<?php

}
else if($page=='user')
{
    
?>         
<?php $this->load->view('admin/user'); ?>

<?php

}
else if($page=='add_user')
{
    
?>         
<?php $this->load->view('admin/add_user'); ?>

<?php

}
else if($page=='edit_user')
{
    
?>         
<?php $this->load->view('admin/edit_user'); ?>

<?php

}

else if($page=='edit_absen')
{
    
?>         
<?php $this->load->view('admin/edit_absen'); ?>

<?php

}


?>