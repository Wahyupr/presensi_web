 <?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=data absensi by_tgl.xls");
?>
   <?php $dari=$_POST['dari']; 
    $sampai=$_POST['sampai'];
    ?>
                         <center> DATA ABSENSI KARYAWAN  </center>

        <center><font size="-5"> DARI TANGGAL <?php echo $dari; ?> SAMPAI TANGGAL <?php echo $sampai; ?></font></center> <p >
               
                                <table border="1">

                                    <thead>
                                        <tr><th ><div align="center">No</div></th>
                                            <th ><div align="center">Nama</div></th>
                                        <th ><div align="center">Tanggal</div></th>
                                            <th><div align="center">Jam MAsuk</div></th>
                                            
                                            <th ><div align="center">Jam Keluar</div></th>
                                            <th ><div align="center">Status</div></th>
                                           
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php $no=1; ?>
                  <?php foreach($dt_search as $d): ?>
                                        <tr >
                <td><div align="center"><?php echo $no++; ?></div></td>
                <td><div align="center"><?php echo $d['nama']; ?> </div></td>
                  <td><div align="center"><?php echo $d['tgl_absensi']; ?> </div></td>
             
                
                 <td><div align="center"><?php echo $d['jam_masuk']; ?> </div></td>
                 <td><div align="center"><?php echo $d['jam_keluar']; ?> </div></td>
                 <td><div align="center"><?php echo $d['status']; ?> </div></td>
                 

                                        
                                      </tr>
                                             <?php endforeach; ?>
                                    </tbody>
                                </table>
        <?php
        exit ()
        ?>
                       