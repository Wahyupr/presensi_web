   <!-- Header -->
    <!-- Header -->
    <div class="header pb-5 d-flex align-items-center" style="min-height: 300px; background-image: url(<?php echo base_url();?>assets/img/theme/karyawan.jpg); background-size: cover; background-position: center top;">
      <!-- Mask -->
      <span class="mask bg-gradient-default opacity-8"></span>
      <!-- Header container -->
      <div class="container-fluid d-flex align-items-center">
        <div class="row">
          <div class="col-lg-7 col-md-10">
            <h1 class="display-2 text-white">Hello <?php echo $this->session->userdata('nama');  ?></h1>
            <p class="text-white mt-0 mb-5">Selamat datang di Sistem Informasi Absensi Berbasis QR Code, DiHalaman ini anda dapat mengelola data absensi</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
       
        <div class="col-xl-12 order-xl-1">
          <div class="card">
            <div class="card-header">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Form Edit Data User</h3>
                </div>
           
              </div>
            </div>
            <div class="card-body">
             
  <?php echo validation_errors();
    echo form_open('admin/update_user'); ?>
              
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                         <input type="hidden" name="id_user" id="input-username" value="<?php echo $d['id_user']; ?>" class="form-control"  >
                        <label class="form-control-label" for="input-username">Nama</label>
                        <input type="text" name="nama" id="input-username" value="<?php echo $d['nama']; ?>" class="form-control"  >
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Jabatan</label>
                        <input type="text" name="jabatan" id="input-email" value="<?php echo $d['jabatan']; ?>" class="form-control" >
                      </div>
                    </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-first-name">NIP</label>
                        <input type="text" name="nip" id="input-first-name" value="<?php echo $d['nip']; ?>" class="form-control" >
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-first-name">Username</label>
                        <input type="text" name="username" id="input-first-name" value="<?php echo $d['username']; ?>" class="form-control" >
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-last-name">Password</label>
                        <input type="password" name="password" id="input-last-name" value="<?php echo $d['password']; ?>" class="form-control" >
                      </div>
                    </div>
                  </div>
                </div>
               
                
               
             <div class="col-4 ">
              
                  <input type="submit" class="btn btn-sm btn-primary" value="Update">
                </div>
             
              </form>



            </div>

          </div>
        </div>
      </div>