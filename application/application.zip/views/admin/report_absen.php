   <!-- Header -->
    <!-- Header -->
    <div class="header pb-6 d-flex align-items-center" style="min-height: 320px; background-image: url(<?php echo base_url();?>assets/img/theme/karyawan.jpg); background-size: cover; background-position: center top;">
      <!-- Mask -->
      <span class="mask bg-gradient-default opacity-8"></span>
      <!-- Header container -->
      <div class="container-fluid d-flex align-items-center">
        <div class="row">
          <div class="col-lg-7 col-md-10">
            <h1 class="display-2 text-white">Hello <?php echo $this->session->userdata('nama');  ?></h1>
            <p class="text-white mt-0 mb-5">Selamat datang di Sistem Informasi Absensi Berbasis QR Code, DiHalaman ini anda dapat mengelola data absensi</p>
            <a  data-toggle="modal" data-target="#myModal" href="#" class="btn btn-neutral">PDF</a>
            <a  data-toggle="modal" data-target="#myModall" href="#" class="btn btn-neutral">Excel</a>
            
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
       
        <div class="col-xl-12 order-xl-1">
          <div class="card">
            <div class="card-header">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Report Absensi</h3>
                </div>
           
              </div>
            </div>
            <div class="card-body">
             
  <div class="table-responsive">

      <div class="modal fade" id="myModall" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                     <h4 class="modal-title" id="myModalLabel">  </h4>
                                        </div>
                                        <div class="modal-body">
                                          
<?php echo validation_errors();
    echo form_open('admin/export_absen_tgl_excel'); ?>
                                  <table width="100%">

          <tr>
             <td height="32">Dari</td>
             <td>:</td>
             <td><input type="date" name="dari" data-options="formatter:myformatter,parser:myparser" style="width:200px;height:25px" ></td>
         </tr>
         <p>
         <tr>
             <td height="32">Sampai</td>
             <td>:</td>
             <td><input type="date" name="sampai" data-options="formatter:myformatter,parser:myparser" style="width:200px;height:25px"></td>
         </tr>
         <tr>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
<td><input type="submit" name="search_submit"  value="Download" class="btn btn-primary">
</td>
        </tr>
       
        </table>
     </form>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
   
               
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                     <h4 class="modal-title" id="myModalLabel">  </h4>
                                        </div>
                                        <div class="modal-body">
                                          
<?php echo validation_errors();
    echo form_open('admin/export_absen_tgl'); ?>
                                  <table width="100%">

          <tr>
             <td height="32">Dari</td>
             <td>:</td>
             <td><input type="date" name="dari" data-options="formatter:myformatter,parser:myparser" style="width:200px;height:25px" ></td>
         </tr>
         <p>
         <tr>
             <td height="32">Sampai</td>
             <td>:</td>
             <td><input type="date" name="sampai" data-options="formatter:myformatter,parser:myparser" style="width:200px;height:25px"></td>
         </tr>
         <tr>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
<td><input type="submit" name="search_submit"  value="Download" class="btn btn-primary">
</td>
        </tr>
       
        </table>
     </form>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                         <table class="table table-striped table-bordered table-hover" id="example1">

                                    <thead>
                                        <tr><th ><div align="center">No</div></th>
                                        <th ><div align="center">Nama Karyawan</div></th>
                                    
                                        <th ><div align="center">Jabatan</div></th>
                                            <th ><div align="center">Tanggal</div></th>
                                        <th ><div align="center">Checkin</div></th>
                                        <th ><div align="center">Checkout</div></th>
                                        <th ><div align="center">Status</div></th>
                                      
                            
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php $no=1; ?>
                  <?php foreach($dt_absen as $d): ?>
                                        <tr >
                                            <td><div align="center"><?php echo $no++; ?></div></td>
                                           
                
                  <td><div align="center"><?php echo $d['nama']; ?> </div></td>
                
                 <td><div align="center"><?php echo $d['jabatan']; ?>  </div></td>
                     <td><div align="center"><?php echo $d['tgl_absensi']; ?>  </div></td>
                 <td><div align="center"><?php echo $d['jam_masuk']; ?>  </div></td>
                 <td><div align="center"><?php echo $d['jam_keluar']; ?>  </div></td>
                 <td><div align="center"><?php echo $d['status']; ?>  </div></td>
             
                
        
       
                                        
                                      </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                      </div>



            </div>
          </div>
        </div>
      </div>